const STORAGE_NOTICIAS = 'positivoNews_noticias'; //cria uma constante que serve como "chave" para salvar e buscar as notícias no localStorage

const getNoticias = () => {  //função getNoticias, vai pegar as notícias salvas no localStorage, se existir algo, retorna a notícia, se nao tiver nada, retorna um array vazio
  try { return JSON.parse(localStorage.getItem(STORAGE_NOTICIAS) || '[]'); }
  catch { return []; }
};

const setNoticias = (arr) => localStorage.setItem(STORAGE_NOTICIAS, JSON.stringify(arr)); //salva as notícias no localStorage
//o "arr" o é array de notícias (as informações que o usuário digitou)
//JSON.stringfy transforma os arrays em texto, pois o localStorage só guarda textos
//localStorage.setItem grava esse texto no navegador

function renderNoticias() {
  const tbody = document.querySelector('#tabelaNoticias tbody');
  if (!tbody) return;
  const data = getNoticias();

  if (data.length === 0) {
    tbody.innerHTML = '<tr><td colspan="5">Nenhuma notícia cadastrada.</td></tr>';
    return;
  } //essa função pega as notícias salvas e mostra na tabela. Se não tiver nenhuma notícia, mostra mensagem "Nenhuma notícia cadastrada"

  const isRelatorio = !document.getElementById('formNoticias');

  tbody.innerHTML = data.map((n, i) => `
    <tr>
      <td>${n.titulo}</td>
      <td>${n.categoria}</td>
      <td>${n.autor}</td>
      <td>${n.data}</td>
      ${isRelatorio ? '' : `
      <td>
        <button class="btn-acao" data-acao="edit" data-i="${i}">Editar</button>
        <button class="btn-acao" data-acao="del" data-i="${i}">Excluir</button>
      </td>`}
    </tr>
  `).join('');
} //essa parte monta a tabela com as notícias salvas, se for uma página de relatório, mostra só os dados, se for a página de cadastro, mostra também os botões de editar e excluir

document.addEventListener('DOMContentLoaded', () => { //todo o código abaixo será executado quando a página terminar de carregar
  renderNoticias();  //logo que o site abre, ele mostra as notícias que estão salvas no localStorage

  const form = document.getElementById('formNoticias');
  const msg = document.getElementById('msgNoticias'); //pega o formulário e o espaço onde as mensagens (de erro ou sucesso) vão aparecer

  if (!form) return; //se a página não tiver formulário (como um relatório) o código para por aqui

  form.addEventListener('submit', (e) => { //quando o usuário clicar em "cadastrar"
    e.preventDefault(); //previne que a página recarregue
    const titulo = document.getElementById('nTitulo').value.trim();
    const categoria = document.getElementById('nCategoria').value.trim();
    const autor = document.getElementById('nAutor').value.trim(); //pega os valores digitados
    const data = document.getElementById('nData').value;
    const resumo = document.getElementById('nResumo').value.trim();
    const idx = document.getElementById('noticiaEditIndex').value;

    if (!titulo || !categoria || !autor || !data) {
      msg.innerHTML = '<p class="erro">Preencha os campos obrigatórios.</p>'; //verificação para ver se os campos estão preenchidos
      return; //se não estiverem, mensagem de erro com "preencha os campos obrigatórios"
    }

    const arr = getNoticias(); //chama a função getNoticias, salva todas as notícias que estavam no localStorage, na variável arr, se não tiver nada salvo, vira um array vazio
    const obj = { titulo, categoria, autor, data, resumo }; //cria um objeto com as informações que o usuário acabou de digitar no formulário

    if (idx !== '') {
      arr[Number(idx)] = obj; //verifica se existe algum valor no campo oculto noticiaEditIndex
      msg.innerHTML = '<p class="sucesso">Notícia atualizada.</p>'; //esse campo guarda o índice (posição do array) da notícia que o usuário está editando, se já tiver um valor, significa q ele clicou em editar em uma notícia já existente
    } else {
      arr.push(obj); //caso não tenha nenhum índice, significa que o usuário não está editando uma notícia já existente e sim está cadastrando uma notícia
      msg.innerHTML = '<p class="sucesso">Notícia cadastrada.</p>';
    }

    setNoticias(arr);
    form.reset();
    document.getElementById('noticiaEditIndex').value = '';
    renderNoticias(); //grava todas as notícias antigas e novas no navegador
  });

  const tabela = document.querySelector('#tabelaNoticias tbody'); //seleciona a área da tabela em que estão os botões de editar e excluir
  if (tabela) { //se a tabela existir, ativa os botões dela quando o usuário clica
    tabela.addEventListener('click', (e) => {
      const btn = e.target.closest('.btn-acao'); //garante que o clique foi em um botão válido
      if (!btn) return;
      const i = Number(btn.dataset.i); //pega o número do índice da notícia (posição dela no array)
      const arr = getNoticias(); //pega as notícias salvas no localStorage, descobre qual notícia foi clicada e pega todas as outras

      if (btn.dataset.acao === 'del') { //verifica se o botão é o de excluir, se for, exclui a notícia e atualiza a lista
        arr.splice(i, 1);
        setNoticias(arr);
        renderNoticias();
      } else { //se não for preenche o formulário com os dados e prepara para serem atualizados
        const n = arr[i];
        document.getElementById('nTitulo').value = n.titulo;
        document.getElementById('nCategoria').value = n.categoria;
        document.getElementById('nAutor').value = n.autor;
        document.getElementById('nData').value = n.data;
        document.getElementById('nResumo').value = n.resumo; //carrega os dados da notícia no formulário para o usuário editar
        document.getElementById('noticiaEditIndex').value = String(i);
        document.getElementById('nTitulo').focus();
      }
    });
  }

  const btnLimpar = document.getElementById('limparNoticias');
  if (btnLimpar) {
    btnLimpar.addEventListener('click', () => {
      if (confirm('Excluir todas as notícias?')) { //se o usuário clicar no botão de limpar, aparece mensagem de confirmação, se prosseguir exclui todas as notícias
        localStorage.removeItem(STORAGE_NOTICIAS); //remove as notícias do localStorage
        renderNoticias(); //atualiza o localStorage
        msg.innerHTML = '<p class="sucesso">Todas as notícias foram removidas.</p>'; //aparece mensagem de sucesso que todas as notícias foram removidas
      }
    });
  }
});
