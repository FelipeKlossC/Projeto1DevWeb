const STORAGE_KEY = 'positivoNews_gamesCuriosities'; //cria uma constante que vai servir como "chave" para salvar as curiosidades no localStorage

/**
 * @returns {Array}
 */
function getCuriosities() { //pega todas as curiosidades que estão salvas no localStorage, se tiver alguma curiosidade, retorna ela, se não tiver retorna um array vazio
    const data = localStorage.getItem(STORAGE_KEY); //essa função busca todas as curiosidades salvas no localStorage, se tiver alguma, ele retorna ela,s e não tiver nenhuma retorna um array vazio
    return data ? JSON.parse(data) : [];
}

/**
 * @param {Array} curiositiesArray
 */
function saveCuriosities(curiositiesArray) { //serve para salvar todas as funções no localStorage, usando o JSON.stringfy para converter em texto
    localStorage.setItem(STORAGE_KEY, JSON.stringify(curiositiesArray));
}

/**
 * @param {Object} newCuriosity 
 */
function addCuriosityToStorage(newCuriosity) {
    const curiosities = getCuriosities(); 
    curiosities.push(newCuriosity);        
    saveCuriosities(curiosities);           //serve para adicionar uma nova curiosidade no localStorage, atualizando o localStorage logo em seguida
}

function renderReports() {
    const curiosities = getCuriosities();
    
    const listaUl = document.getElementById('lista-curiosidades-salvas');
    const totalSpan = document.getElementById('total-curiosidades');
    
    listaUl.innerHTML = '';
    totalSpan.textContent = curiosities.length; //serve para atualizar as curiosidades na tela, se não tive rnenhuma, mostra mensagem de nenhuma curiosidade cadastrada ainda

    if (curiosities.length === 0) {
        listaUl.innerHTML = '<li style="color: gray;">Nenhuma curiosidade cadastrada ainda.</li>';
    } else {
        curiosities.forEach((curiosity, index) => {
            const li = document.createElement('li');
            li.innerHTML = `
                <strong>${index + 1}. ${curiosity.titulo}</strong> 
                (Criado em: ${curiosity.dataCriacao}) 
                <br><small>${curiosity.descricao.substring(0, 80)}...</small>
            `;
            listaUl.appendChild(li);
        });
    }

}

const formCuriosidade = document.getElementById('form-curiosidade');
formCuriosidade.addEventListener('submit', function(evento) {
    evento.preventDefault(); //garante que a página nao seja recarregada após o envio do formulário 

    const novaCuriosidade = {
        id: Date.now(),
        titulo: document.getElementById('titulo').value,
        descricao: document.getElementById('descricao').value,
        imagem: { //pega todas as informações digitadas pelo usuário e transforma em um objeto pronto para ser salvo no localStorage
            src: document.getElementById('imagem-src').value,
            alt: document.getElementById('imagem-alt').value
        },
        dataCriacao: new Date().toLocaleDateString('pt-BR')
    };

    addCuriosityToStorage(novaCuriosidade);
    renderReports();

    formCuriosidade.reset();
    document.getElementById('mensagem-status').textContent = 'Curiosidade adicionada e salva!';
    setTimeout(() => { //salva a curiosidade, atualiza o localStorage mostra uma mensagem com duração de 5 segundos
        document.getElementById('mensagem-status').textContent = '';
    }, 5000);
});

const btnLimparDados = document.getElementById('btn-limpar-dados');
btnLimparDados.addEventListener('click', function() {
    if (confirm('Tem certeza que deseja APAGAR TODAS as curiosidades salvas localmente?')) {
        localStorage.removeItem(STORAGE_KEY);
        renderReports(); //quando o usuário clicar no toão e na confirmação, exclui todas as curiosidade do localStorage
        document.getElementById('mensagem-limpeza').textContent = 'Todos os dados de curiosidades de games foram removidos.';
        
        setTimeout(() => {
            document.getElementById('mensagem-limpeza').textContent = '';
        }, 5000);
    }
});

document.addEventListener('click', function(e){
  const trigger = e.target.closest('.menu-dropdown > .has-sub');
  const dropdown = e.target.closest('.menu-dropdown');

  if (trigger) {
    e.preventDefault();
    const open = trigger.getAttribute('aria-expanded') === 'true';
    trigger.setAttribute('aria-expanded', String(!open));
    const submenu = trigger.parentElement.querySelector('.submenu');
    submenu.style.display = open ? 'none' : 'block';
    return;
  }

  document.querySelectorAll('.menu-dropdown').forEach(function(md){
    const a = md.querySelector('.has-sub');
    const sm = md.querySelector('.submenu');
    if (a && sm && !md.contains(e.target)) {
      a.setAttribute('aria-expanded','false');
      sm.style.display = ''; //faz um menu que quando clica, abre aparecendo novas seções e quando clica fora dele, fecha o mesmo
    }
  });
});


document.addEventListener('DOMContentLoaded', renderReports);

console.log('index.js carregado com Local Storage e Relatórios.');

  document.addEventListener('DOMContentLoaded', () => {
    const toggle = document.querySelector('.menu-toggle');
    const nav = document.querySelector('.navegacao');

    toggle.addEventListener('click', () => { //qnd a página abre, o menu com as curiosidades carrega através do renderReports
      const ativo = nav.classList.toggle('active');
      toggle.classList.toggle('active', ativo);
      toggle.setAttribute('aria-expanded', ativo);
    });
  });