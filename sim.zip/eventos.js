const STORAGE_EVENTOS = 'positivoNews_eventos'; //cria uma constante que vai servir como "chave" para salvar os eventos no localStorage

const getEventos = () => { //vai pegar os eventos cadastrados no localStorage, se tiver um evento, retorna ele, se não tiver, retorna um array vazio
  try { return JSON.parse(localStorage.getItem(STORAGE_EVENTOS) || '[]'); }
  catch { return []; }
};
const setEventos = (arr) => localStorage.setItem(STORAGE_EVENTOS, JSON.stringify(arr)); //transforma o valor em texto usando o JSON.stringfy pois no localStorage só aceita texto

function renderEventos() {
  const tbody = document.querySelector('#tabelaEventos tbody');
  if (!tbody) return;
  const data = getEventos();

  if (data.length === 0) {
    tbody.innerHTML = '<tr><td colspan="5">Nenhum evento cadastrado.</td></tr>';
    return;
  }

  const isRelatorio = !document.getElementById('formEventos');

  tbody.innerHTML = data.map((ev, i) => `
    <tr>
      <td>${ev.titulo}</td>
      <td>${ev.local}</td>
      <td>${ev.data}</td>
      <td>${ev.hora}</td>
      ${isRelatorio ? '' : `
      <td>
        <button class="btn-acao" data-acao="edit" data-i="${i}">Editar</button>
        <button class="btn-acao" data-acao="del" data-i="${i}">Excluir</button>
      </td>`}
    </tr>
  `).join('');
} //a função pega todos os eventos salvos e atualiza a tabela no HTML

document.addEventListener('DOMContentLoaded', () => {  //garante que, assim que a página abrir, a tabela de eventos já apareça com os dados salvos anteriormente
  renderEventos();

  const form = document.getElementById('formEventos');
  const msg = document.getElementById('msgEventos'); //essas duas linhas pegam do html o formulário de eventos e a área de mensagens, pro javascript ler os dados do formulário e exibir mensagem de sucesso ou erro

  if (!form) return; //se nao tiver formulário o comando para

  form.addEventListener('submit', (e) => { //quando o usuário aperta no toão de cadastrar, o formulário recebe os dados abaixo
    e.preventDefault(); //faz com q a página não recarregue
    const titulo = document.getElementById('eTitulo').value.trim();
    const local = document.getElementById('eLocal').value.trim();
    const data = document.getElementById('eData').value;
    const hora = document.getElementById('eHora').value;
    const desc = document.getElementById('eDesc').value.trim();
    const idx = document.getElementById('eventoEditIndex').value;

    if (!titulo || !local || !data || !hora) { //verificação, se não tiver preenchido algum desses campos, mensagem de erro
      msg.innerHTML = '<p class="erro">Preencha os campos obrigatórios.</p>';
      return;
    }

    const arr = getEventos();  // chama a função getEventos, salva todos os eventos que estavam no localStorage na variável arr, se não tiver nada vira um array vazio
    const obj = { titulo, local, data, hora, desc }; //cria um objeto com as informações que o usuário digitou

    if (idx !== '') { //verifica se tem um valor no campo oculto eventoEditIndex, se tiver, significa que o usuario esta editando um evento já existente, então ele atualiza o array com o valor da posição
      arr[Number(idx)] = obj;
      msg.innerHTML = '<p class="sucesso">Evento atualizado.</p>';
    } else {
      arr.push(obj); //se não tiver nenhum valor, significa q é um cadastro novo, ent vai pra ultima posição do array
      msg.innerHTML = '<p class="sucesso">Evento cadastrado.</p>';
    }

    setEventos(arr);
    form.reset();
    document.getElementById('eventoEditIndex').value = '';
    renderEventos(); //grava todas as notícias antigas e novas no navgegador
  });

  const tabela = document.querySelector('#tabelaEventos tbody'); //seleciona a área da tabela em que  estão os botões de editar e excluir
  if (tabela) { //se a tabela existir, ativa os botões nela quando o usuário clicar
    tabela.addEventListener('click', (e) => {
      const btn = e.target.closest('.btn-acao'); //garante que o click foi em um botão válido
      if (!btn) return;
      const i = Number(btn.dataset.i); //pega o número do indice (posição do evento no array)
      const arr = getEventos(); //pega o evento salva no localStorage, verifica qual evento foi clicado e pega todos os outros

      if (btn.dataset.acao === 'del') { //verifica se o botão é o de excluir, se for, exclui o evento e atualiza a tabela
        arr.splice(i, 1);
        setEventos(arr);
        renderEventos();
      } else {
        const ev = arr[i];
        document.getElementById('eTitulo').value = ev.titulo;  //carrega os dados do evento pro usuário editar
        document.getElementById('eLocal').value = ev.local;
        document.getElementById('eData').value = ev.data;
        document.getElementById('eHora').value = ev.hora; //se não for, preenche o formulário com os dados e prepara para serem atualizados 
        document.getElementById('eDesc').value = ev.desc;
        document.getElementById('eventoEditIndex').value = String(i);
        document.getElementById('eTitulo').focus();
      }
    });
  }

  const btnLimpar = document.getElementById('limparEventos');
  if (btnLimpar) {
    btnLimpar.addEventListener('click', () => { //se o usuário clicar no botão, exclui todos os eventos
      if (confirm('Excluir todos os eventos?')) {
        localStorage.removeItem(STORAGE_EVENTOS); //remove os eventos do loalStorage
        renderEventos(); 
        msg.innerHTML = '<p class="sucesso">Todos os eventos foram removidos.</p>';
      }
    });
  }
});
