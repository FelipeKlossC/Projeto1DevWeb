const STORAGE_USUARIOS = 'positivoNews_usuarios'; //cria a constante STORAGE_USUARIOS como chave para salvar e buscar os usuários no localStorage

const lsGet = (k) => { //vai pegar os usuários salvos no localStorage, se tiver algo, retorna o usuário, se não tiver nada, retorna um array vazio
  try { return JSON.parse(localStorage.getItem(k) || '[]'); }
  catch { return []; }
};
const lsSet = (k, v) => localStorage.setItem(k, JSON.stringify(v)); //transforma o valor em texto com JSON.stringify, pois o localStorage só aceita texto

function renderTabela() {
  const tbody = document.querySelector('#tabela-usuarios tbody');
  if (!tbody) return;

  const data = lsGet(STORAGE_USUARIOS);
  tbody.innerHTML = data.map((u, i) => `
    <tr>
      <td>${u.nome}</td>
      <td>${u.email}</td>
      <td>${u.idade}</td>
      <td>${u.linguagem}</td>
      <td>${u.sexo}</td>
      <td>
        ${document.getElementById('cadastroForm')
          ? `<button class="btn-acao" data-acao="edit" data-i="${i}">Editar</button>`
          : ''}
        <button class="btn-acao" data-acao="del" data-i="${i}">Excluir</button>
      </td>
    </tr>
  `).join('');
} //a função pega todos os usuários salvos e atualiza a tabela do html com essas informações

function resetForm() {
  const form = document.getElementById('cadastroForm');
  if (form) { //se o formulário for encontrado no HTML, executa o bloco de comandos de reset dos campos
    form.reset();
    document.getElementById('editIndex').value = '';
  }
} //a função limpa todos os campos do formulário

document.addEventListener('DOMContentLoaded', () => {
  renderTabela(); //garante que, assim que a página abrir, a tabela de usuários já apareça com os dados salvos anteriormente
  const form = document.getElementById('cadastroForm'); //pega o formulário da página através do ID
  if (form) {
    form.addEventListener('submit', function(e) { //quando o usuário clicar em cadastrar, recebe os valores abaixo
      e.preventDefault(); //serve para impedir que o site recarregue a página
      const nome = document.getElementById('nome').value.trim();
      const email = document.getElementById('email').value.trim();
      const idade = parseInt(document.getElementById('idade').value);
      const senha = document.getElementById('senha').value.trim();
      const confirmarSenha = document.getElementById('confirmarSenha').value.trim();
      const linguagem = document.getElementById('linguagem').value; //recebe os valores digitados pelo usuário
      const dataNascimento = document.getElementById('dataNascimento').value;
      const corFavorita = document.getElementById('corFavorita').value;
      const satisfacao = document.getElementById('satisfacao').value;
      const sexoEl = document.querySelector('input[name="sexo"]:checked');
      const preferenciasEl = document.querySelectorAll('input[name="preferencias"]:checked');
      const mensagem = document.getElementById('mensagem');
      const editIndex = document.getElementById('editIndex');
      mensagem.innerHTML = '';

      if (!nome || !email || !idade || !senha || !confirmarSenha || !linguagem || !dataNascimento || !sexoEl) {
        mensagem.innerHTML = '<p class="erro">Preencha todos os campos obrigatórios.</p>'; //verifica se os campos estão preenchidos, se não estiverem, mensagem de erro
        return;
      }

      if (!email.includes('@') || !email.includes('.')) {
        mensagem.innerHTML = '<p class="erro">Insira um e-mail válido.</p>'; //verifica se o email possui @ ou . se não tiver, mensagem de erro
        return;
      }

      if (idade < 18 || idade > 100) {
        mensagem.innerHTML = '<p class="erro">Idade deve estar entre 18 e 100 anos.</p>'; //verifica se a idade é menor que 18 ou maior que 100, se não atender aos requisitos, mensagem de erro
        return;
      }

      if (senha.length < 6) { //verifica se a senha tem menos de 6 caracteres, se tiver, mensagem de erro pois tem q ter mais que 6 caracteres
        mensagem.innerHTML = '<p class="erro">A senha deve ter no mínimo 6 caracteres.</p>';
        return;
      }

      if (senha !== confirmarSenha) { //verifica se a senha colocada no confirmar senha é diferente da senha colocada no campo senha
        mensagem.innerHTML = '<p class="erro">As senhas não coincidem.</p>';
        return;
      }

      const preferencias = Array.from(preferenciasEl).map(p => p.value); //cria um array com os valores de todas as checkbox marcadas
      const usuario = {
        nome, email, idade, senha, linguagem, dataNascimento, corFavorita,
        satisfacao, sexo: sexoEl.value, preferencias //cria um objetivo "usuário" com todos os dados coletados no formulário
      };

      const arr = lsGet(STORAGE_USUARIOS); //pega a lista de usuários já salva no localStorage
      if (editIndex.value !== '') { //se o campo editIndex não estiver vazio significa que o usuário está editando um cadastro existente
        arr[Number(editIndex.value)] = usuario; //atualiza o cadastro com os novos dados
        mensagem.innerHTML = '<p class="sucesso">Usuário atualizado com sucesso!</p>'; //mensagem de sucesso
      } else {
        arr.push(usuario); //caso contrário é um novo cadastro, adicionando o novo usuário á lista
        mensagem.innerHTML = '<p class="sucesso">Cadastro realizado com sucesso!</p>';
      }

      lsSet(STORAGE_USUARIOS, arr); //salva no localStorage a lista de usuários atualizada, transformando o array em texto
      renderTabela(); //recarrega a tabela na tela, mostrando o novo usuário cadastrado ou o usuário registrado
      resetForm(); //limpa todos os campos do formulário
    });
  }

  const tabela = document.querySelector('#tabela-usuarios tbody'); //pega o copro da tabela (tbody) onde estão as linhas com os usuários
  if (tabela) { //só executa o bloco de comandos se a tabela existir na página
    tabela.addEventListener('click', (e) => { //escuta qualquer clique dentro da tela
      const btn = e.target.closest('.btn-acao'); //verifica se o clique foi em algum notão com a classe btn-acao
      if (!btn) return; //se não foi, sai da função
      const i = Number(btn.dataset.i); //pega o índice do usuário no array 
      const arr = lsGet(STORAGE_USUARIOS); //busca todos os usuários salvos no localStorage

      if (btn.dataset.acao === 'del') { //se for botão de excluir
        arr.splice(i, 1); //remove um elemento da posição 1 (usuário excluído)
        lsSet(STORAGE_USUARIOS, arr); //salva a atualização no localStorage
        renderTabela(); //renderiza a tabela com a nova atualização
      } else if (btn.dataset.acao === 'edit' && form) { //se for botão de editar
        const u = arr[i]; //pega os dados do usuário cadastrado
        document.getElementById('nome').value = u.nome;
        document.getElementById('email').value = u.email;
        document.getElementById('idade').value = u.idade;
        document.getElementById('senha').value = u.senha;
        document.getElementById('confirmarSenha').value = u.senha;
        document.getElementById('linguagem').value = u.linguagem;
        document.getElementById('dataNascimento').value = u.dataNascimento;
        document.getElementById('corFavorita').value = u.corFavorita; //repete para todos os dados
        document.getElementById('satisfacao').value = u.satisfacao;

        document.querySelectorAll('input[name="sexo"]').forEach(r => r.checked = (r.value === u.sexo));
        document.querySelectorAll('input[name="preferencias"]').forEach(c => c.checked = u.preferencias.includes(c.value)); //também marca os inputs de radiogroup e checkbox

        document.getElementById('editIndex').value = String(i); //guarda o índice do usuário que está sendo editado (para atualizar depois)
        document.getElementById('nome').focus(); //coloca o cursor automaticamente no campo de nome
      }
    });
  }

  const limpar = document.getElementById('limpar-usuarios'); //pega o botão de limpar usuários pelo ID
  if (limpar) { //só executa o bloco de comandos se o botão existir
    limpar.addEventListener('click', () => { //adiciona um evento de clique no botão
      if (confirm('Excluir todos os usuários cadastrados?')) { //pergunta confirmando se quer excluir todos os usuários cadastrados
        localStorage.removeItem(STORAGE_USUARIOS); //remove todos os usuários cadastrados salvos no localStorage
        renderTabela(); //renderiza novamente a tabela atualizada, agora com nenhum usuário
        const msg = document.getElementById('mensagem');
        if (msg) msg.innerHTML = '<p class="sucesso">Todos os usuários foram removidos.</p>'; //mostra a mensagem de todos os usuários foram removidos
      }
    });
  }
});
