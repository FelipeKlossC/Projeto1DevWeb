const btnLogin = document.getElementById('btnLogin');
const btnFechar = document.getElementById('btnFechar'); //cria constantes botões de login e fechar que estavam presentes no html 

const login = document.getElementById('login');  //pega o id da janela modal
const formLogin = document.querySelector('#login form'); //pega o formulário dentro desse modal

btnLogin.onclick = function () {
    login.showModal(); //quando clicar em login abre o modal
}
btnFechar.onclick = function () {
    login.close(); //qnd clicar em fechar fecha o modal
}

let dadosUsuario =[
    {nome: "Bruno", email: "souza6486@gmail.com", senha: "123"} //define as informações do usuario
];
formLogin.addEventListener('submit', (evento) => {
    evento.preventDefault(); //qnd clica em enviar impede que a página seja recarregada
let email = document.getElementById('email').value;
let senha = document.getElementById('senha').value; //pega os valores recebidos
let usuarioEncontrado = false; 
dadosUsuario.forEach((cliente) => {
    if(email == cliente.email && senha == cliente.senha){
        usuarioEncontrado = true; //se as informações baterem, mensagem de usuario logado
        sessionStorage.setItem('usuarioLogado', true);

        window.location.href = "./admin.html"; //mostra a página do admin
    }
});
let usuarioLogado = sessionStorage.getItem('usuarioLogado');

if(!usuarioEncontrado){
    let erro = document.createElement('p'); //se usuário n for encontrado, mensagem de erro e reseta os campos do formulário
    erro.classList.add('erro');
    erro.innerText = 'Login ou senha invalido';

    login.insertBefore(erro,login.firstChild);

    document.querySelector('#login form').reset();
}
   


});